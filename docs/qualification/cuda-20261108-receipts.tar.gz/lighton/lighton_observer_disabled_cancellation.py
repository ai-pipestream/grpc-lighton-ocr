"""Diagnostic cancellation only: counters disabled must remain unverified.

The ordinary hardware gate remains unchanged and rejects this mode. This
wrapper retains its valid-stream cancellation and full recovery content and
geometry checks, but explicitly asserts unknown placement instead.
"""
import sys

sys.path.insert(0, '/work/main/grpc-services/worktrees/grpc-lighton-ocr-cuda-20261108/tests')
import hardware_rpc_test as checks
import hardware_cancellation_test as cancellation

def assert_unverified(provenance, backend):
    stages = provenance.get('stages', [])
    checks.require(len(stages) == 2, 'two stage identities remain available')
    checks.require({s.get('stage') for s in stages} == {
        'INFERENCE_STAGE_VISION', 'INFERENCE_STAGE_DECODER'}, 'both stages required')
    for stage in stages:
        checks.require(stage.get('backend') == checks.BACKENDS[backend], 'requested backend identity')
        checks.require(not stage.get('runtimeVerified', False), 'disabled observer cannot verify execution')
        checks.require('cpuCompute' not in stage, 'disabled observer cannot disclose unknown computation')
        checks.require(bool(stage.get('deviceName')) and bool(stage.get('deviceId')), 'native device identity')

checks.validate_placement = assert_unverified
cancellation.main()
